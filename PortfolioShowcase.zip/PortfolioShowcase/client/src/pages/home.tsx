import Navigation from "@/components/navigation";
import HeroSection from "@/components/hero-section";
import AboutSection from "@/components/about-section";
import ExperienceTimeline from "@/components/experience-timeline";
import SkillsSection from "@/components/skills-section";
import ExpertiseSection from "@/components/expertise-section";
import PodcastSection from "@/components/podcast-section";
import ArticlesSection from "@/components/articles-section";
import ContactSection from "@/components/contact-section";
import Footer from "@/components/footer";

export default function Home() {
  return (
    <div className="font-inter bg-gray-50 text-gray-900">
      <Navigation />
      <HeroSection />
      <AboutSection />
      <ExperienceTimeline />
      <SkillsSection />
      <ExpertiseSection />
      <PodcastSection />
      <ArticlesSection />
      <ContactSection />
      <Footer />
    </div>
  );
}
