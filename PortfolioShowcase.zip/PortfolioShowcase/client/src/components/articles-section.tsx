import { motion } from "framer-motion";
import { BookOpen, Calendar, ArrowRight, FileText, PenTool, Globe } from "lucide-react";
import { Button } from "@/components/ui/button";

export default function ArticlesSection() {
  // Placeholder articles - can be updated with real content when available
  const articles = [
    {
      title: "Digital Transformation in Government: A Roadmap for Success",
      excerpt: "Exploring key strategies for implementing digital transformation initiatives in government organizations.",
      date: "Coming Soon",
      category: "Digital Governance",
      status: "upcoming"
    },
    {
      title: "IFMS Implementation: Best Practices and Challenges",
      excerpt: "Insights from real-world implementations of Integrated Financial Management Systems across Indian states.",
      date: "Coming Soon",
      category: "Financial Systems",
      status: "upcoming"
    },
    {
      title: "Direct Benefit Transfer: Modernizing Public Service Delivery",
      excerpt: "Analyzing the impact of DBT digitization on public service efficiency and citizen satisfaction.",
      date: "Coming Soon",
      category: "Public Policy",
      status: "upcoming"
    }
  ];

  return (
    <section id="articles" className="py-20 bg-gradient-to-b from-white to-slate-50 relative overflow-hidden">
      {/* Background decorative elements */}
      <div className="absolute inset-0 opacity-3">
        <div className="absolute top-20 left-1/4 w-88 h-88 bg-gradient-to-br from-amber-400 to-orange-500 rounded-full filter blur-3xl"></div>
        <div className="absolute bottom-20 right-1/4 w-96 h-96 bg-gradient-to-br from-cyan-400 to-blue-500 rounded-full filter blur-3xl"></div>
      </div>
      
      <div className="container mx-auto px-4 relative z-10">
        <motion.div 
          className="text-center mb-16"
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          viewport={{ once: true }}
        >
          <h2 className="text-4xl font-bold text-gray-900 mb-4 font-inter">Articles & Insights</h2>
          <p className="text-xl text-gray-600 font-inter">Thoughts on policy, governance, and digital transformation</p>
        </motion.div>
        
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8 mb-12">
          {articles.map((article, index) => (
            <motion.div 
              key={index}
              className="bg-white/90 backdrop-blur-sm rounded-xl shadow-lg hover:shadow-xl transition-all duration-300 border border-gray-100/50 p-6"
              initial={{ opacity: 0, y: 50 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: index * 0.1 }}
              viewport={{ once: true }}
              whileHover={{ scale: 1.02, y: -5 }}
            >
              <div className="flex items-center mb-4">
                <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center mr-4">
                  <FileText className="text-primary" size={24} />
                </div>
                <div>
                  <span className="text-sm text-primary font-medium">{article.category}</span>
                  <div className="flex items-center text-sm text-gray-500 mt-1">
                    <Calendar size={14} className="mr-1" />
                    {article.date}
                  </div>
                </div>
              </div>
              
              <h3 className="text-xl font-semibold text-gray-900 mb-3 font-inter">{article.title}</h3>
              <p className="text-gray-600 mb-4 line-clamp-3 font-inter">{article.excerpt}</p>
              
              <div className="flex justify-between items-center">
                <span className="text-sm text-orange-600 font-medium bg-orange-100 px-3 py-1 rounded-full">
                  {article.status === "upcoming" ? "Coming Soon" : "Read More"}
                </span>
                <ArrowRight className="text-gray-400" size={20} />
              </div>
            </motion.div>
          ))}
        </div>
        
        <motion.div 
          className="text-center"
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          viewport={{ once: true }}
        >
          <div className="bg-white/90 backdrop-blur-sm rounded-xl shadow-lg p-8 border border-gray-100/50 max-w-2xl mx-auto">
            <div className="flex items-center justify-center mb-6">
              <div className="w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center mr-4">
                <PenTool className="text-primary" size={32} />
              </div>
              <div>
                <h3 className="text-2xl font-bold text-gray-900 font-inter">Stay Updated</h3>
                <p className="text-gray-600 font-inter">New articles on policy and governance coming soon</p>
              </div>
            </div>
            
            <p className="text-gray-700 mb-6 font-inter">
              I regularly share insights on government effectiveness, digital transformation, and public policy. 
              Follow me on LinkedIn for the latest updates and thought leadership content.
            </p>
            
            <Button 
              asChild
              className="bg-blue-600 hover:bg-blue-700 text-white px-8 py-3 rounded-lg font-semibold transition-colors"
            >
              <a 
                href="https://www.linkedin.com/in/sanjida-akhtar/" 
                target="_blank" 
                rel="noopener noreferrer"
                className="flex items-center space-x-2"
              >
                <Globe size={20} />
                <span>Follow on LinkedIn</span>
              </a>
            </Button>
          </div>
        </motion.div>
      </div>
    </section>
  );
}