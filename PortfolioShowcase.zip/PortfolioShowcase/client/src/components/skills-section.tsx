import { motion } from "framer-motion";
import { Users, TrendingUp, Settings, ClipboardCheck, Shield, Monitor, BarChart3, Handshake } from "lucide-react";

export default function SkillsSection() {
  const technicalSkills = [
    { name: "Government Digital Transformation", level: 95 },
    { name: "Policy Analysis & Drafting", level: 90 },
    { name: "IFMS/CFMS Implementation", level: 90 },
    { name: "DBT System Design", level: 88 },
    { name: "Data Analysis & Visualization", level: 85 },
    { name: "Dashboard Development", level: 82 },
    { name: "Taxation Reform", level: 85 },
    { name: "Aadhaar Integration", level: 92 },
  ];

  const professionalSkills = [
    { icon: Users, title: "Stakeholder Management", subtitle: "Cross-functional coordination" },
    { icon: TrendingUp, title: "Policy Development", subtitle: "Strategic planning" },
    { icon: ClipboardCheck, title: "Policy Analysis", subtitle: "Research & evaluation" },
    { icon: Shield, title: "Policy Drafting", subtitle: "Legislative documentation" },
    { icon: Settings, title: "Change Management", subtitle: "Organizational transformation" },
    { icon: Monitor, title: "Digital Governance", subtitle: "E-governance solutions" },
    { icon: BarChart3, title: "Data Analysis", subtitle: "Insights & visualization" },
    { icon: Handshake, title: "Business Development", subtitle: "Strategic partnerships" },
  ];

  return (
    <section id="skills" className="py-20 bg-gradient-to-b from-gray-100 to-white relative overflow-hidden">
      {/* Background pattern */}
      <div className="absolute inset-0 opacity-3">
        <div className="absolute top-1/4 right-1/3 w-72 h-72 bg-gradient-to-br from-emerald-400 to-teal-500 rounded-full filter blur-3xl"></div>
        <div className="absolute bottom-1/4 left-1/3 w-64 h-64 bg-gradient-to-br from-teal-400 to-cyan-400 rounded-full filter blur-3xl"></div>
      </div>
      
      <div className="container mx-auto px-4 relative z-10">
        <motion.div 
          className="text-center mb-16"
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          viewport={{ once: true }}
        >
          <h2 className="text-4xl font-bold text-gray-900 mb-4 font-inter">Core Competencies</h2>
          <p className="text-xl text-gray-600 font-inter">Technical expertise and professional skills</p>
        </motion.div>
        
        <div className="grid md:grid-cols-2 gap-12">
          {/* Technical Skills */}
          <motion.div
            initial={{ opacity: 0, x: -50 }}
            whileInView={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.6 }}
            viewport={{ once: true }}
          >
            <h3 className="text-2xl font-semibold mb-8 text-gray-900 font-inter">Technical Expertise</h3>
            <div className="space-y-6">
              {technicalSkills.map((skill, index) => (
                <motion.div 
                  key={index}
                  initial={{ opacity: 0, x: -20 }}
                  whileInView={{ opacity: 1, x: 0 }}
                  transition={{ duration: 0.4, delay: index * 0.1 }}
                  viewport={{ once: true }}
                >
                  <div className="flex justify-between mb-2">
                    <span className="text-gray-700 font-inter">{skill.name}</span>
                    <span className="text-gray-500 font-inter">{skill.level}%</span>
                  </div>
                  <div className="w-full bg-gray-200 rounded-full h-2">
                    <motion.div 
                      className="bg-primary h-2 rounded-full"
                      initial={{ width: 0 }}
                      whileInView={{ width: `${skill.level}%` }}
                      transition={{ duration: 1, delay: index * 0.1 }}
                      viewport={{ once: true }}
                    />
                  </div>
                </motion.div>
              ))}
            </div>
          </motion.div>
          
          {/* Professional Skills */}
          <motion.div
            initial={{ opacity: 0, x: 50 }}
            whileInView={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.6 }}
            viewport={{ once: true }}
          >
            <h3 className="text-2xl font-semibold mb-8 text-gray-900 font-inter">Professional Skills</h3>
            <div className="grid grid-cols-2 lg:grid-cols-4 gap-6">
              {professionalSkills.map((skill, index) => (
                <motion.div 
                  key={index}
                  className="bg-white/60 backdrop-blur-sm p-6 rounded-xl text-center hover:bg-white/80 transition-all duration-300 shadow-md hover:shadow-lg border border-gray-100/50"
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.4, delay: index * 0.1 }}
                  viewport={{ once: true }}
                  whileHover={{ scale: 1.05, y: -2 }}
                >
                  <skill.icon className="mx-auto text-3xl text-primary mb-4" />
                  <h4 className="font-semibold text-gray-900 mb-2 font-inter">{skill.title}</h4>
                  <p className="text-sm text-gray-600 font-inter">{skill.subtitle}</p>
                </motion.div>
              ))}
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
