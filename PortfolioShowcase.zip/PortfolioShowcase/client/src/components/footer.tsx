import { Mail, Linkedin, Mic } from "lucide-react";

export default function Footer() {
  return (
    <footer className="bg-gradient-to-b from-gray-900 to-black text-white py-12 relative overflow-hidden">
      {/* Background pattern */}
      <div className="absolute inset-0 opacity-5">
        <div className="absolute top-0 left-1/4 w-64 h-64 bg-blue-500 rounded-full filter blur-3xl"></div>
        <div className="absolute bottom-0 right-1/4 w-48 h-48 bg-indigo-500 rounded-full filter blur-3xl"></div>
      </div>
      
      <div className="container mx-auto px-4 relative z-10">
        <div className="text-center">
          <div className="text-3xl font-bold mb-4 font-inter">Sanjida A.</div>
          <p className="text-gray-400 mb-8 font-inter">Government & Finance Professional | Digital Transformation Specialist</p>
          <div className="flex justify-center space-x-6 mb-8">
            <a href="mailto:sanjida.a05@outlook.com" className="text-gray-400 hover:text-white transition-colors">
              <Mail size={24} />
            </a>
            <a href="https://www.linkedin.com/in/sanjida-akhtar/" target="_blank" rel="noopener noreferrer" className="text-gray-400 hover:text-white transition-colors">
              <Linkedin size={24} />
            </a>
            <a href="https://open.spotify.com/show/5LU4vm3Fs4od3u6Q16nC3l" target="_blank" rel="noopener noreferrer" className="text-gray-400 hover:text-white transition-colors">
              <Mic size={24} />
            </a>
          </div>
          <p className="text-gray-400 text-sm font-inter">© 2024 Sanjida A. All rights reserved.</p>
        </div>
      </div>
    </footer>
  );
}
