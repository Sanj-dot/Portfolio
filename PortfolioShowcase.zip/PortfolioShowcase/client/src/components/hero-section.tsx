import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import { User, Award, TrendingUp, Users } from "lucide-react";
import Logo from "@/components/logo";

export default function HeroSection() {
  const handleNavClick = (href: string) => {
    const element = document.querySelector(href);
    if (element) {
      element.scrollIntoView({ behavior: "smooth" });
    }
  };

  return (
    <section id="home" className="min-h-screen relative bg-gradient-to-br from-slate-800 via-purple-900 to-indigo-900 text-white flex items-center pt-20 overflow-hidden">
      {/* Professional geometric background */}
      <div className="absolute inset-0 opacity-10">
        <div className="absolute top-20 left-10 w-96 h-96 bg-gradient-to-br from-purple-400 to-indigo-500 rounded-full filter blur-3xl animate-pulse"></div>
        <div className="absolute top-40 right-20 w-80 h-80 bg-gradient-to-br from-indigo-400 to-blue-500 rounded-full filter blur-3xl animate-pulse delay-1000"></div>
        <div className="absolute bottom-20 left-1/3 w-72 h-72 bg-gradient-to-br from-blue-400 to-purple-500 rounded-full filter blur-3xl animate-pulse delay-2000"></div>
      </div>
      
      {/* Subtle geometric patterns */}
      <div className="absolute inset-0 opacity-5">
        <div className="absolute top-1/4 left-1/4 w-32 h-32 border border-white/20 rotate-45 animate-spin-slow"></div>
        <div className="absolute bottom-1/4 right-1/4 w-24 h-24 border border-white/20 rotate-12 animate-bounce-slow"></div>
        <div className="absolute top-1/2 left-1/2 w-16 h-16 border border-white/10 rotate-0 animate-pulse"></div>
      </div>
      
      {/* Professional grid pattern */}
      <div className="absolute inset-0 opacity-5">
        <div className="absolute inset-0" style={{
          backgroundImage: `radial-gradient(circle at 1px 1px, rgba(255,255,255,0.15) 1px, transparent 0)`,
          backgroundSize: '20px 20px'
        }}></div>
      </div>
      
      <div className="container mx-auto px-4 relative z-10">
        <div className="flex flex-col lg:flex-row items-center justify-between">
          <motion.div 
            className="lg:w-1/2 text-center lg:text-left mb-12 lg:mb-0"
            initial={{ opacity: 0, y: 50 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
          >
            <motion.div 
              className="mb-6"
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.6 }}
            >
              <Logo size="lg" className="mx-auto lg:mx-0 mb-4" />
            </motion.div>
            
            <h1 className="text-5xl lg:text-7xl font-bold mb-4 font-inter tracking-tight">
              Sanjida <span className="text-purple-300">A</span>khtar
            </h1>
            <h2 className="text-2xl lg:text-3xl font-light mb-6 text-purple-100 font-inter">
              Government & Finance Professional
            </h2>
            <p className="text-xl mb-8 opacity-90 leading-relaxed font-inter">
              Transforming public sector efficiency through policy analysis, digital innovation, 
              data analysis, business development, and stakeholder engagement across multiple Indian states.
            </p>
            
            {/* Professional highlights */}
            <div className="flex flex-wrap gap-4 mb-8 justify-center lg:justify-start">
              <div className="flex items-center bg-white/10 backdrop-blur-sm px-4 py-2 rounded-full">
                <Award className="w-4 h-4 mr-2 text-purple-300" />
                <span className="text-sm font-medium">7+ Years Experience</span>
              </div>
              <div className="flex items-center bg-white/10 backdrop-blur-sm px-4 py-2 rounded-full">
                <TrendingUp className="w-4 h-4 mr-2 text-purple-300" />
                <span className="text-sm font-medium">Policy Analysis</span>
              </div>
              <div className="flex items-center bg-white/10 backdrop-blur-sm px-4 py-2 rounded-full">
                <Users className="w-4 h-4 mr-2 text-purple-300" />
                <span className="text-sm font-medium">Digital Transformation</span>
              </div>
            </div>
            
            <div className="flex flex-col sm:flex-row gap-4 justify-center lg:justify-start">
              <Button 
                onClick={() => handleNavClick("#contact")}
                className="bg-white text-slate-900 px-8 py-3 rounded-lg font-semibold hover:bg-purple-50 transition-all duration-300 shadow-xl hover:shadow-2xl font-inter"
              >
                Get In Touch
              </Button>
              <Button 
                onClick={() => handleNavClick("#podcast")}
                variant="outline"
                className="border-2 border-white/80 text-white px-8 py-3 rounded-lg font-semibold hover:bg-white/10 backdrop-blur-sm transition-all duration-300 font-inter"
              >
                Listen to Podcast
              </Button>
            </div>
          </motion.div>
          
          <motion.div 
            className="lg:w-1/2 flex justify-center"
            initial={{ opacity: 0, scale: 0.8 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.8, delay: 0.2 }}
          >
            <div className="relative">
              {/* Professional circular frame */}
              <div className="w-80 h-80 bg-gradient-to-br from-white/20 to-white/10 backdrop-blur-sm rounded-full flex items-center justify-center border border-white/30 shadow-2xl">
                <div className="w-64 h-64 bg-gradient-to-br from-emerald-400/30 to-teal-500/30 rounded-full flex items-center justify-center">
                  <User className="text-6xl text-white opacity-80" />
                </div>
              </div>
              
              {/* Decorative elements */}
              <div className="absolute -top-4 -right-4 w-8 h-8 bg-emerald-400 rounded-full animate-pulse"></div>
              <div className="absolute -bottom-4 -left-4 w-6 h-6 bg-teal-400 rounded-full animate-pulse delay-1000"></div>
              <div className="absolute top-1/2 -left-8 w-4 h-4 bg-cyan-400 rounded-full animate-pulse delay-2000"></div>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
