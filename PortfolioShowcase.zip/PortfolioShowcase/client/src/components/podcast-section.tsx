import { motion } from "framer-motion";
import { Mic, Play, ExternalLink, Headphones } from "lucide-react";
import { Button } from "@/components/ui/button";

export default function PodcastSection() {
  return (
    <section id="podcast" className="py-20 bg-gradient-to-b from-gray-50 to-white relative overflow-hidden">
      {/* Background decorative elements */}
      <div className="absolute inset-0 opacity-3">
        <div className="absolute top-20 right-1/4 w-80 h-80 bg-gradient-to-br from-emerald-400 to-teal-500 rounded-full filter blur-3xl"></div>
        <div className="absolute bottom-20 left-1/4 w-96 h-96 bg-gradient-to-br from-teal-400 to-cyan-500 rounded-full filter blur-3xl"></div>
      </div>
      
      <div className="container mx-auto px-4 relative z-10">
        <motion.div 
          className="text-center mb-16"
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          viewport={{ once: true }}
        >
          <h2 className="text-4xl font-bold text-gray-900 mb-4 font-inter">Policy Charcha Podcast</h2>
          <p className="text-xl text-gray-600 font-inter">Discussing policy, governance, and public sector transformation</p>
        </motion.div>
        
        <div className="max-w-4xl mx-auto">
          <motion.div 
            className="bg-white/90 backdrop-blur-sm rounded-2xl shadow-xl p-8 border border-gray-100/50"
            initial={{ opacity: 0, y: 50 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
          >
            <div className="flex flex-col lg:flex-row items-center gap-8">
              <div className="lg:w-1/3">
                <motion.div 
                  className="w-64 h-64 mx-auto bg-gradient-to-br from-emerald-500 to-teal-600 rounded-2xl flex items-center justify-center shadow-2xl"
                  whileHover={{ scale: 1.05 }}
                  transition={{ duration: 0.3 }}
                >
                  <Mic className="text-white text-8xl" />
                </motion.div>
              </div>
              
              <div className="lg:w-2/3">
                <h3 className="text-3xl font-bold text-gray-900 mb-4 font-inter">Policy Charcha</h3>
                <p className="text-lg text-gray-700 mb-6 font-inter">
                  Join me on Policy Charcha, where we dive deep into the world of public policy, governance, and digital transformation. 
                  Each episode explores critical issues in government effectiveness, policy implementation, and the future of public service delivery.
                </p>
                
                <div className="grid md:grid-cols-2 gap-4 mb-8">
                  <div className="flex items-center space-x-3">
                    <Headphones className="text-primary" size={20} />
                    <span className="text-gray-700 font-inter">Policy & Governance</span>
                  </div>
                  <div className="flex items-center space-x-3">
                    <Play className="text-primary" size={20} />
                    <span className="text-gray-700 font-inter">Digital Transformation</span>
                  </div>
                  <div className="flex items-center space-x-3">
                    <Mic className="text-primary" size={20} />
                    <span className="text-gray-700 font-inter">Expert Interviews</span>
                  </div>
                  <div className="flex items-center space-x-3">
                    <ExternalLink className="text-primary" size={20} />
                    <span className="text-gray-700 font-inter">Available on Spotify</span>
                  </div>
                </div>
                
                <motion.div
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                >
                  <Button 
                    asChild
                    className="bg-green-600 hover:bg-green-700 text-white px-8 py-3 rounded-lg font-semibold transition-colors font-inter"
                  >
                    <a 
                      href="https://open.spotify.com/show/5LU4vm3Fs4od3u6Q16nC3l" 
                      target="_blank" 
                      rel="noopener noreferrer"
                      className="flex items-center space-x-2"
                    >
                      <Play size={20} />
                      <span>Listen on Spotify</span>
                      <ExternalLink size={16} />
                    </a>
                  </Button>
                </motion.div>
              </div>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}