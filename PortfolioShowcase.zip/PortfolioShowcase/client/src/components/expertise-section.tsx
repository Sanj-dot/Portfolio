import { motion } from "framer-motion";
import { University, Coins, Smartphone, BarChart3, Shield, Leaf, TrendingUp, Handshake, FileText } from "lucide-react";

export default function ExpertiseSection() {
  const expertiseAreas = [
    {
      icon: University,
      title: "Government Transformation",
      description: "Expertise in modernizing government operations through digital transformation, process reengineering, and institutional capacity building.",
      tags: ["Digital Governance", "Process Reengineering", "Capacity Building"],
      color: "blue",
    },
    {
      icon: Coins,
      title: "Finance Management",
      description: "Specialization in financial systems modernization, budget management, and revenue optimization for state governments.",
      tags: ["IFMS/CFMS", "Budget Planning", "Revenue Enhancement"],
      color: "green",
    },
    {
      icon: Smartphone,
      title: "Digital Integration",
      description: "Leading implementation of Aadhaar-based systems, DBT digitization, and e-KYC integration for seamless public service delivery.",
      tags: ["DBT Systems", "Aadhaar Integration", "e-KYC"],
      color: "purple",
    },
    {
      icon: BarChart3,
      title: "Data Analysis & Dashboards",
      description: "Developing comprehensive data analysis frameworks, creating interactive dashboards, and providing actionable insights for strategic decision-making.",
      tags: ["Data Analysis", "Dashboard Development", "Business Intelligence"],
      color: "orange",
    },
    {
      icon: Handshake,
      title: "Business Development",
      description: "Strategic business development initiatives, partnership building, and market analysis to drive organizational growth and stakeholder engagement.",
      tags: ["Business Strategy", "Partnership Development", "Market Analysis"],
      color: "indigo",
    },
    {
      icon: FileText,
      title: "Policy Analysis & Drafting",
      description: "Comprehensive policy research, analysis, and legislative drafting to create evidence-based policy recommendations and regulatory frameworks.",
      tags: ["Policy Research", "Legislative Drafting", "Regulatory Framework"],
      color: "red",
    },
    {
      icon: Shield,
      title: "Risk Management",
      description: "Expertise in identifying financial risks, establishing audit frameworks, and implementing governance structures for public sector organizations.",
      tags: ["Risk Assessment", "Audit Frameworks", "Governance"],
      color: "red",
    },
    {
      icon: Leaf,
      title: "Environmental Governance",
      description: "Experience in environmental policy implementation, pollution monitoring systems, and climate-smart governance initiatives.",
      tags: ["Environmental Policy", "Climate Smart Cities", "Sustainability"],
      color: "teal",
    },
  ];

  const getColorClasses = (color: string) => {
    const colorMap = {
      blue: "bg-blue-100 text-blue-800",
      green: "bg-green-100 text-green-800",
      purple: "bg-purple-100 text-purple-800",
      orange: "bg-orange-100 text-orange-800",
      red: "bg-red-100 text-red-800",
      teal: "bg-teal-100 text-teal-800",
      indigo: "bg-indigo-100 text-indigo-800",
    };
    return colorMap[color as keyof typeof colorMap] || "bg-gray-100 text-gray-800";
  };

  return (
    <section id="projects" className="py-20 bg-gradient-to-b from-white to-gray-50 relative overflow-hidden">
      {/* Background elements */}
      <div className="absolute inset-0 opacity-3">
        <div className="absolute top-10 left-10 w-80 h-80 bg-gradient-to-br from-emerald-400 to-teal-500 rounded-full filter blur-3xl transform rotate-45"></div>
        <div className="absolute bottom-10 right-10 w-96 h-96 bg-gradient-to-br from-teal-400 to-cyan-500 rounded-full filter blur-3xl transform -rotate-45"></div>
        <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-64 h-64 bg-gradient-to-br from-cyan-400 to-blue-400 rounded-full filter blur-3xl"></div>
      </div>
      
      <div className="container mx-auto px-4 relative z-10">
        <motion.div 
          className="text-center mb-16"
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          viewport={{ once: true }}
        >
          <h2 className="text-4xl font-bold text-gray-900 mb-4 font-inter">Areas of Expertise</h2>
          <p className="text-xl text-gray-600 font-inter">Specialized domains and focus areas</p>
        </motion.div>
        
        <div className="grid md:grid-cols-3 gap-8">
          {expertiseAreas.map((area, index) => (
            <motion.div 
              key={index}
              className="bg-white/90 backdrop-blur-sm p-8 rounded-xl shadow-lg hover:shadow-xl transition-all duration-300 border border-gray-100/50"
              initial={{ opacity: 0, y: 50 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: index * 0.1 }}
              viewport={{ once: true }}
              whileHover={{ scale: 1.02, y: -5 }}
            >
              <div className="text-center mb-6">
                <area.icon className="mx-auto text-5xl text-primary mb-4" />
                <h3 className="text-xl font-semibold text-gray-900 font-inter">{area.title}</h3>
              </div>
              <p className="text-gray-700 mb-6 font-inter">{area.description}</p>
              <div className="space-y-2">
                {area.tags.map((tag, tagIndex) => (
                  <span 
                    key={tagIndex}
                    className={`inline-block px-3 py-1 rounded-full text-sm ${getColorClasses(area.color)} mr-2`}
                  >
                    {tag}
                  </span>
                ))}
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
