import { motion } from "framer-motion";

export default function ExperienceTimeline() {
  const experiences = [
    {
      period: "June 2024 - Present",
      title: "Assistant Manager",
      company: "Grant Thornton India",
      description: "Leading diagnostic studies and digital transformation initiatives for state finance departments, focusing on taxation efficiency and ICT-enabled governance.",
      side: "left",
    },
    {
      period: "March 2023 - May 2025",
      title: "Senior Consultant",
      company: "KPMG India",
      description: "Conducted comprehensive assessments of state finance systems, DBT processes, and IFMS portals for multiple state governments including Gujarat and Chhattisgarh.",
      side: "right",
    },
    {
      period: "June 2022 - Feb 2023",
      title: "Consultant",
      company: "Deutsche Gesellschaft für Internationale Zusammenarbeit (GIZ)",
      description: "Led climate smart city initiatives, conducting cross-municipality financial analysis and developing evidence-based policy recommendations.",
      side: "left",
    },
    {
      period: "April 2021 - May 2022",
      title: "Consultant",
      company: "Andhra Pradesh Government",
      description: "Implemented comprehensive finance management systems, risk assessment frameworks, and project management tools for state government operations.",
      side: "right",
    },
  ];

  return (
    <section id="experience" className="py-20 bg-gradient-to-b from-white to-slate-50 relative overflow-hidden">
      {/* Background decorative elements */}
      <div className="absolute inset-0 opacity-3">
        <div className="absolute top-20 left-1/4 w-96 h-96 bg-gradient-to-r from-blue-400 to-purple-400 rounded-full filter blur-3xl transform rotate-12"></div>
        <div className="absolute bottom-20 right-1/4 w-80 h-80 bg-gradient-to-r from-indigo-400 to-blue-400 rounded-full filter blur-3xl transform -rotate-12"></div>
      </div>
      
      <div className="container mx-auto px-4 relative z-10">
        <motion.div 
          className="text-center mb-16"
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          viewport={{ once: true }}
        >
          <h2 className="text-4xl font-bold text-gray-900 mb-4 font-inter">Professional Experience</h2>
          <p className="text-xl text-gray-600 font-inter">My journey in government and finance sector</p>
        </motion.div>
        
        <div className="relative">
          {/* Timeline Line */}
          <div className="absolute left-1/2 transform -translate-x-1/2 w-1 h-full bg-primary hidden md:block"></div>
          
          {/* Timeline Items */}
          <div className="space-y-12">
            {experiences.map((exp, index) => (
              <motion.div 
                key={index}
                className="flex flex-col md:flex-row items-center"
                initial={{ opacity: 0, y: 50 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: index * 0.1 }}
                viewport={{ once: true }}
              >
                {exp.side === "left" ? (
                  <>
                    <div className="md:w-1/2 md:pr-8 mb-4 md:mb-0">
                      <div className="bg-white/90 backdrop-blur-sm p-6 rounded-xl shadow-lg hover:shadow-xl transition-all duration-300 border border-gray-100/50">
                        <div className="flex items-center mb-4">
                          <div className="w-3 h-3 bg-primary rounded-full mr-3"></div>
                          <span className="text-sm text-gray-500">{exp.period}</span>
                        </div>
                        <h3 className="text-xl font-semibold text-gray-900 mb-2">{exp.title}</h3>
                        <h4 className="text-lg text-primary mb-3">{exp.company}</h4>
                        <p className="text-gray-700">{exp.description}</p>
                      </div>
                    </div>
                    <div className="hidden md:block w-4 h-4 bg-primary rounded-full border-4 border-white z-10"></div>
                    <div className="md:w-1/2 md:pl-8"></div>
                  </>
                ) : (
                  <>
                    <div className="md:w-1/2 md:pr-8"></div>
                    <div className="hidden md:block w-4 h-4 bg-primary rounded-full border-4 border-white z-10"></div>
                    <div className="md:w-1/2 md:pl-8 mb-4 md:mb-0">
                      <div className="bg-white/90 backdrop-blur-sm p-6 rounded-xl shadow-lg hover:shadow-xl transition-all duration-300 border border-gray-100/50">
                        <div className="flex items-center mb-4">
                          <div className="w-3 h-3 bg-primary rounded-full mr-3"></div>
                          <span className="text-sm text-gray-500">{exp.period}</span>
                        </div>
                        <h3 className="text-xl font-semibold text-gray-900 mb-2">{exp.title}</h3>
                        <h4 className="text-lg text-primary mb-3">{exp.company}</h4>
                        <p className="text-gray-700">{exp.description}</p>
                      </div>
                    </div>
                  </>
                )}
              </motion.div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
