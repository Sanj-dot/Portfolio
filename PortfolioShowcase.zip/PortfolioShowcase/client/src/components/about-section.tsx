import { motion } from "framer-motion";
import { CheckCircle, Mail, Linkedin, MapPin } from "lucide-react";

export default function AboutSection() {
  const achievements = [
    "Led digital transformation initiatives across multiple state governments",
    "Implemented DBT digitization and IFMS/CFMS enhancements",
    "Developed comprehensive data analysis frameworks and interactive dashboards",
    "Conducted policy analysis and drafted legislative frameworks",
    "Facilitated Aadhaar-based e-KYC integration for streamlined services",
    "Specialized in stakeholder coordination and change management",
    "Executed business development strategies for organizational growth",
  ];

  return (
    <section id="about" className="py-20 bg-gradient-to-b from-gray-50 to-white relative overflow-hidden">
      {/* Professional background pattern */}
      <div className="absolute inset-0 opacity-5">
        <div className="absolute top-10 right-10 w-96 h-96 bg-gradient-to-br from-emerald-500 to-teal-600 rounded-full filter blur-3xl"></div>
        <div className="absolute bottom-10 left-10 w-80 h-80 bg-gradient-to-br from-teal-500 to-cyan-600 rounded-full filter blur-3xl"></div>
      </div>
      
      {/* Subtle grid pattern */}
      <div className="absolute inset-0 opacity-[0.02]">
        <div className="absolute inset-0" style={{
          backgroundImage: `linear-gradient(to right, #059669 1px, transparent 1px), linear-gradient(to bottom, #059669 1px, transparent 1px)`,
          backgroundSize: '40px 40px'
        }}></div>
      </div>
      
      <div className="container mx-auto px-4 relative z-10">
        <motion.div 
          className="text-center mb-16"
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          viewport={{ once: true }}
        >
          <h2 className="text-4xl font-bold text-gray-900 mb-4 font-inter">About Me</h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto font-inter">
            A dedicated professional with 7+ years of experience in government effectiveness, taxation reform, and digital transformation.
          </p>
        </motion.div>
        
        <div className="grid md:grid-cols-2 gap-12 items-center">
          <motion.div
            initial={{ opacity: 0, x: -50 }}
            whileInView={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.6 }}
            viewport={{ once: true }}
          >
            <h3 className="text-2xl font-semibold mb-6 text-gray-900 font-inter">Professional Summary</h3>
            <p className="text-gray-700 mb-6 font-inter">
              Currently serving as Assistant Manager at Grant Thornton India, I specialize in public policy and finance with extensive experience in government effectiveness, taxation reform, and digital transformation across multiple Indian states.
            </p>
            <p className="text-gray-700 mb-6 font-inter">
              My expertise includes driving Direct Benefit Transfer (DBT) digitization, IFMS/CFMS enhancements, and Aadhaar-based e-KYC integration to streamline public service delivery. I also specialize in policy analysis and drafting, business development, data analysis, and creating interactive dashboards that provide actionable insights for strategic decision-making.
            </p>
            <div className="space-y-4">
              <div className="flex items-center space-x-4">
                <Mail className="text-primary" size={20} />
                <span className="text-gray-700 font-inter">sanjida.a05@outlook.com</span>
              </div>
              <div className="flex items-center space-x-4">
                <Linkedin className="text-primary" size={20} />
                <a 
                  href="https://www.linkedin.com/in/sanjida-akhtar/" 
                  target="_blank" 
                  rel="noopener noreferrer"
                  className="text-gray-700 hover:text-primary transition-colors font-medium font-inter"
                >
                  Connect on LinkedIn
                </a>
              </div>
            </div>
          </motion.div>
          
          <motion.div 
            className="bg-white/60 backdrop-blur-sm p-8 rounded-xl shadow-lg border border-gray-100/50"
            initial={{ opacity: 0, x: 50 }}
            whileInView={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.6 }}
            viewport={{ once: true }}
          >
            <h3 className="text-2xl font-semibold mb-6 text-gray-900">Key Achievements</h3>
            <div className="space-y-4">
              {achievements.map((achievement, index) => (
                <motion.div 
                  key={index}
                  className="flex items-start space-x-3"
                  initial={{ opacity: 0, x: 20 }}
                  whileInView={{ opacity: 1, x: 0 }}
                  transition={{ duration: 0.4, delay: index * 0.1 }}
                  viewport={{ once: true }}
                >
                  <CheckCircle className="text-green-500 mt-1 flex-shrink-0" size={20} />
                  <span className="text-gray-700">{achievement}</span>
                </motion.div>
              ))}
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
