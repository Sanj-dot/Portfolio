import React from "react";

interface LogoProps {
  className?: string;
  size?: "sm" | "md" | "lg";
}

export default function Logo({ className = "", size = "md" }: LogoProps) {
  const sizeClasses = {
    sm: "w-8 h-8",
    md: "w-10 h-10",
    lg: "w-12 h-12"
  };

  return (
    <div className={`${sizeClasses[size]} ${className}`}>
      <svg
        viewBox="0 0 120 120"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
        className="w-full h-full"
      >
        {/* Elegant monogram with professional styling */}
        <defs>
          <linearGradient id="logoGradient" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor="#7c3aed" />
            <stop offset="100%" stopColor="#c084fc" />
          </linearGradient>
        </defs>
        
        {/* Outer ring */}
        <circle
          cx="60"
          cy="60"
          r="55"
          stroke="url(#logoGradient)"
          strokeWidth="3"
          fill="none"
          className="drop-shadow-sm"
        />
        
        {/* Inner elegant frame */}
        <circle
          cx="60"
          cy="60"
          r="45"
          stroke="url(#logoGradient)"
          strokeWidth="1"
          fill="none"
          opacity="0.5"
        />
        
        {/* Stylized "S" */}
        <path
          d="M35 40 C35 35, 40 30, 50 30 C60 30, 65 35, 65 40 C65 45, 60 50, 50 50 C40 50, 35 55, 35 60 C35 65, 40 70, 50 70 C60 70, 65 75, 65 80 C65 85, 60 90, 50 90 C40 90, 35 85, 35 80"
          stroke="url(#logoGradient)"
          strokeWidth="3"
          fill="none"
          strokeLinecap="round"
          strokeLinejoin="round"
        />
        
        {/* Stylized "A" */}
        <path
          d="M75 90 L85 30 L95 90 M80 65 L90 65"
          stroke="url(#logoGradient)"
          strokeWidth="3"
          fill="none"
          strokeLinecap="round"
          strokeLinejoin="round"
        />
        
        {/* Decorative elements */}
        <circle cx="60" cy="25" r="2" fill="url(#logoGradient)" opacity="0.7" />
        <circle cx="60" cy="95" r="2" fill="url(#logoGradient)" opacity="0.7" />
        <circle cx="25" cy="60" r="2" fill="url(#logoGradient)" opacity="0.7" />
        <circle cx="95" cy="60" r="2" fill="url(#logoGradient)" opacity="0.7" />
      </svg>
    </div>
  );
}

// Professional text logo component
export function TextLogo({ className = "" }: { className?: string }) {
  return (
    <div className={`font-inter font-bold text-2xl tracking-wide text-primary ${className}`}>
      <span className="text-3xl">S</span>anjida{" "}
      <span className="text-3xl">A</span>khtar
    </div>
  );
}